/** @type {import('next').NextConfig} */
module.exports = {
  images: {
    domains: ['downloader.disk.yandex.ru', 'avatars.yandex.net']
  },
}
