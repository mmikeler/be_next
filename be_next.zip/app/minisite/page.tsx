export default async function Page(params: any) {
  return (
    <div className="container mx-auto p-6">
      <h1 className="text-2xl">Молчание - золото</h1>
    </div>
  )
}