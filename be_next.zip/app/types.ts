

export type Session = {
    user: {
        name: string,
        email: string,
        avatar: string,
        id: number,
        ya_disk: string
    }
}