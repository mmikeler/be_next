import { Colorpicker } from "."


export function Colors() {
  return (
    <Colorpicker styleProp="backgroundColor" label="Фон" />
  )
}